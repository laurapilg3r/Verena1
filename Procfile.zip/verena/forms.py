from django import forms
from django.forms import ModelForm
from verenaApp.models import Person

class Cadastrar(forms.Form):
    class meta:
        model = Person
        fields = ['nome', 'email', 'data_nasc', 'num_cell', 'msg']
        labels = {'nome': ("Nome"), 'email' : 'Email', 'data_nasc': 'Data de nascimento', 'num_cell': 'Número do celular', 'msg': 'Mensagem'}
        help_texts = {'nome': 'Insira o seu nome', 'email': 'Insira o seu email', 'data_nasc':'Insira a data de nascimento', 'num_cell':'Insira o número do celular', 'msg': "Digite uma mensagem"}
            