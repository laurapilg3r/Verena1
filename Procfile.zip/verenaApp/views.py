from django.shortcuts import render
from django.views.generic.edit import CreateView
from verenaApp.models import Person

class marcosCreateView(CreateView):
    model = Person
        
    fields = [
        'nome',
        'email',
        'data_nasc',
        'num_cell',
        'msg'
    ]
    template_name='index.html'
    success_url=""