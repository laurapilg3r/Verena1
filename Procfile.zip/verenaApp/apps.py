from django.apps import AppConfig


class VerenaappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'verenaApp'
