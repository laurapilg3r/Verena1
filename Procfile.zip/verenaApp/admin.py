from django.contrib import admin
from verenaApp.models import Person, Empresa, Cidade, Ramo

admin.site.register(Person)
admin.site.register(Empresa)
admin.site.register(Cidade)
admin.site.register(Ramo)