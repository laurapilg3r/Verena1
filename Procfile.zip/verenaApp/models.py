from django.db import models

class Person (models.Model):
    nome = models.CharField(max_length = 40, verbose_name = 'nome')
    email = models.EmailField(verbose_name='email')
    data_nasc = models.DateField(verbose_name='data de nascimento')
    num_cell = models.CharField(max_length = 100, verbose_name='número do celular')
    msg= models.CharField(max_length=300, verbose_name = 'mensagem')
    
class Empresa (models.Model):
    nome_emp= models.CharField(max_length=20)
    
class Cidade (models.Model):
    nome=models.CharField(max_length=30)
    pais=models.CharField(max_length=40)
    estado=models.CharField(max_length=2)
    
class Ramo (models.Model):
    nome_ramo= models.CharField(max_length=30)
